# Siddhi Softwares: BACKEND (admin panel + API + uploads)

Run:   ADMIN_PASS=yourpassword node server.js        (Node 18+, no npm install)
Admin: http://localhost:3000/admin/   (user: admin)
API:   GET /api/public  (frontend reads this)   POST /api/lead   /api/admin/*  (login needed)

Environment variables
  PORT         default 3000
  ADMIN_USER   default admin
  ADMIN_PASS   set a strong password
  DATA_DIR     folder for db.json + uploads/  (keep on a persistent disk, back it up)
  BASE_URL     public address of this backend, e.g. https://api.siddhisoftwares.com
               (used so uploaded image links work on the website)
  SECRET       optional, keeps admin logins valid across restarts

In Admin > Settings and SEO set "Website address" to the FRONTEND domain (https://siddhisoftwares.com).

v3: new admin tabs Products, Hero slider, Technologies. Video upload (MP4/WebM, max 50 MB) saved in DATA_DIR/uploads. Existing databases get the new demo products, slides and technologies added automatically on first start; change the email in Admin > Settings if it still shows the old one.

v6: on first start, an existing database automatically gets the new products (16, with images), 8 new blog articles and 6 new hero slides. Items you already edited are not overwritten (only empty image/SEO fields are filled). The 3 old demo hero slides are set to Draft (re-publish them in Admin if you want them).

v7: bigger hero panel; the headline and the 'Talk to our team' button are now inside the panel. Admin > Settings no longer has 'Hero text', 'Hero small badge text' and 'Hero coloured line' (removed from the website). 'Hero button text' and 'Hero button link' still work (empty link = Contact page). Hero slider images: wide landscape, best 1920x900 px.

v8: bigger logo, brand name in the header is now orange, header slightly taller (92px on desktop). Brand name text still comes from Admin > Settings > Brand name.

v9: Admin image fields now show a live preview (also for assets/img/... paths: the backend serves ../frontend/assets at /assets/, set FRONTEND_DIR if your frontend folder is elsewhere). On upload a crop window opens (presets: Hero 1920x900, 16:9, product 16:10, 4:3, square, share image, keep original). "Crop / resize" button re-crops an existing image. Admin "View website" / "Open" now go to the frontend (http://localhost:4000 locally; set FRONTEND_URL in production, otherwise the "Website address" setting is used).

v10: three main products added first in Products: Mobile App Development, Web App Development, Desktop App Development (cover image, content, 5 FAQs, SEO). On first start an existing database gets them automatically (once) and the older demo products move below them. Edit or delete any product from Admin > Products.

v11: blog post 'Online Exam Application' added (published, with SEO title/description/keywords, short answer, 7 FAQs). Detail pages now also output Article and FAQPage structured data. Existing databases get the post once on first start.

v12: blog post 'Transport management system (TMS) guide' added (SEO + GEO). New field 'Related page' (type/slug) in Admin for products, solutions, services, case studies, industries and blog posts: shows a 'Read the full guide' box on the product page and a 'Related product and pages' box on the article. Transport and Online Exam products, solutions and case studies are linked to their blog articles (done once on first start for existing databases).
